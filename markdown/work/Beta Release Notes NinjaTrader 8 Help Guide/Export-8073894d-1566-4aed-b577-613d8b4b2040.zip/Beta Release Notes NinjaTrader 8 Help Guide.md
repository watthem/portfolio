# Beta Release Notes - NinjaTrader 8 Help Guide

Company: NinjaTrader LLC
Status: Ready
Stub: Through the two-year beta release cycle of NinjaTrader 8, I was responsible for compiling and writing release notes that described the changes for each iteration up until the final release candidate.
Subject Matter: NinjaScript, NinjaTrader
Technology Used: Confluence, Help+Manual, JIRA
URL: https://ninjatrader.com/support/helpGuides/nt8/?beta_release_notes.htm

![Beta%20Release%20Notes%20NinjaTrader%208%20Help%20Guide/Untitled.png](Beta%20Release%20Notes%20NinjaTrader%208%20Help%20Guide/Untitled.png)