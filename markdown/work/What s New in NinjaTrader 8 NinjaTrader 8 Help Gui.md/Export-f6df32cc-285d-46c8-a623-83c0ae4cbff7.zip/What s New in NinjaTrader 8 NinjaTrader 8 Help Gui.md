# What's New in NinjaTrader 8 - NinjaTrader 8 Help Guide

Company: NinjaTrader LLC
Status: Completed
Stub: My first assignment as a Jr. Product Manger for NinjaTrader was to compile, review, and publish technical copy for marketing teams to tease content to users eagerly waiting the milestone release of NinjaTrader version 8. Much of the technical copy used in this document is being reused by NinjaTrader's marketing team in the form of Tweets and Blog content.
Subject Matter: NinjaTrader
Technology Used: Confluence, Help+Manual, JIRA, Word
URL: https://ninjatrader.com/support/helpGuides/nt8/whats_new.htm

![What%20s%20New%20in%20NinjaTrader%208%20NinjaTrader%208%20Help%20Gui/Untitled.png](What%20s%20New%20in%20NinjaTrader%208%20NinjaTrader%208%20Help%20Gui/Untitled.png)