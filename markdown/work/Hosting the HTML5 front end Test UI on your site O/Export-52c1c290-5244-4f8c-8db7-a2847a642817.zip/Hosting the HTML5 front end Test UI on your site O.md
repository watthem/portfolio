# Hosting the HTML5 front-end Test UI on your site – Ookla Speedtest Custom

Company: Ookla (Speedtest.net)
Status: Ready
Stub: Since many of Ookla's customers were new to the concept of using a HTML5 client hosted from another web server, we needed to build a template to assist users with building their own web pages that displayed the test content through use of an iframe.
Subject Matter: HTML5
Technology Used: ZenDesk
URL: https://support.ookla.com/hc/en-us/articles/115001660712-Hosting-the-HTML5-front-end-Test-UI-on-your-site

![Hosting%20the%20HTML5%20front%20end%20Test%20UI%20on%20your%20site%20O/Untitled.png](Hosting%20the%20HTML5%20front%20end%20Test%20UI%20on%20your%20site%20O/Untitled.png)