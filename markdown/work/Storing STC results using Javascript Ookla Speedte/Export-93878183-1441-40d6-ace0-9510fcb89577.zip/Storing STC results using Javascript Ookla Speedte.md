# Storing STC results using Javascript – Ookla Speedtest Custom

Company: Ookla (Speedtest.net)
Status: Ready
Stub: To help with proving a popular use case, we provided a code sample written in PHP to help demonstrate how data could be exchanged from Javascript to a SQL database.
Subject Matter: Cross-Origin Resource Sharing (CORS), JavaScript, PHP, SQL, XHR
Technology Used: ZenDesk
URL: https://support.ookla.com/hc/en-us/articles/360000725112-Storing-STC-results-using-Javascript

![Storing%20STC%20results%20using%20Javascript%20Ookla%20Speedte/Untitled.png](Storing%20STC%20results%20using%20Javascript%20Ookla%20Speedte/Untitled.png)