# Unable to verify HTTPS server configuration – Ookla Speedtest Custom

Company: Ookla (Speedtest.net)
Status: Ready
Stub: To support latest browser security protocols, it was it was important that vendors follow guidelines to ensure their server networking software could pass routine security monitoring watchdog process developed by Ookla.
Subject Matter: HTTPS, SSL Certificates, Transport Layer Security (TLS)
Technology Used: ZenDesk
URL: https://support.ookla.com/hc/en-us/articles/115003334412-Unable-to-verify-HTTPS-server-configuration

![Unable%20to%20verify%20HTTPS%20server%20configuration%20Ookla%20/Untitled.png](Unable%20to%20verify%20HTTPS%20server%20configuration%20Ookla%20/Untitled.png)