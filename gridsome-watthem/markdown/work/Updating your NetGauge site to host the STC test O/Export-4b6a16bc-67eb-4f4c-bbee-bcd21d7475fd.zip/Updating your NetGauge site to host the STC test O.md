# Updating your NetGauge site to host the STC test – Ookla Speedtest Custom

Company: Ookla (Speedtest.net)
Status: Ready
Stub: The client-side technology used to execute and host a test on a customer's website was completely rehauled and required a different approach to get similar results on the client's site. We worked to make this process as simple as possible, which often confused users who were used to a more complicated approach to hosting the test engine.
Subject Matter: CSS, HTML5
Technology Used: ZenDesk
URL: https://support.ookla.com/hc/en-us/articles/115001650351-Updating-your-NetGauge-site-to-host-the-STC-test

![Updating%20your%20NetGauge%20site%20to%20host%20the%20STC%20test%20O/Untitled.png](Updating%20your%20NetGauge%20site%20to%20host%20the%20STC%20test%20O/Untitled.png)