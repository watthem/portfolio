# CME Reduces Tick Size of EUR/USD Futures - NinjaTrader Blog

Company: NinjaTrader LLC
Status: Ready
Stub: Between my time as technical support lead and product manager, it was often my job to help catch wide-spread issues before they caused issues for the ecosystem of users. We often authored In Product Advisories that were also re-hosted on the NinjaTrader blog to assist in these scenarios. This is one example of the many advisories that I helped write and edit.
Subject Matter: NinjaTrader
Technology Used: Confluence, Help+Manual, JIRA
URL: https://ninjatrader.com/blog/cme-reduces-tick-size-of-eurusd-futures-2/

![CME%20Reduces%20Tick%20Size%20of%20EUR%20USD%20Futures%20NinjaTrad/Untitled.png](CME%20Reduces%20Tick%20Size%20of%20EUR%20USD%20Futures%20NinjaTrad/Untitled.png)