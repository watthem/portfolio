# User Migration - Ookla Speedtest Custom

Company: Ookla (Speedtest.net)
Status: Ready
Stub: Ookla – the team behind http://speedtest.net/ – also offers an enterprise version of their flagship website software used to measure bandwidth and latency between a client and server. During the transition from legacy Flash protocols to new HTML5/Javscript versions, I lead a small team of technical service contractors to assist with the increased workload from the transition.
Subject Matter: Speedtest Custom
Technology Used: ZenDesk
URL: https://www.ookla.com/speedtest-custom

![User%20Migration%20Ookla%20Speedtest%20Custom/Untitled.png](User%20Migration%20Ookla%20Speedtest%20Custom/Untitled.png)