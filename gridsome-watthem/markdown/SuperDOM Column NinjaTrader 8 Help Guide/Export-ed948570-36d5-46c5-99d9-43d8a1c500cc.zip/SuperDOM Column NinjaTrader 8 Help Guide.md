# SuperDOM Column - NinjaTrader 8 Help Guide

Company: NinjaTrader LLC
Status: Ready
Stub: A flagship order entry feature for day traders was enhanced to allow users to write custom add-ons using C# scripts that would interact with the WPF layouts provided by NinjaTrader. This is the API reference documentation to allow a user to start using these types.
Subject Matter: .NET, C#, NinjaScript, WPF
Technology Used: Confluence, Help+Manual, JIRA
URL: https://ninjatrader.com/support/helpGuides/nt8/?superdom_column.htm

![SuperDOM%20Column%20NinjaTrader%208%20Help%20Guide/Untitled.png](SuperDOM%20Column%20NinjaTrader%208%20Help%20Guide/Untitled.png)

![SuperDOM%20Column%20NinjaTrader%208%20Help%20Guide/Untitled%201.png](SuperDOM%20Column%20NinjaTrader%208%20Help%20Guide/Untitled%201.png)