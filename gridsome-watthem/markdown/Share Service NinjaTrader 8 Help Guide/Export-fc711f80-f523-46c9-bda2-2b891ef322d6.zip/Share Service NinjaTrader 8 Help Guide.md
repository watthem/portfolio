# Share Service - NinjaTrader 8 Help Guide

Company: NinjaTrader LLC
Status: Ready
Stub: NinjaTrader version 8 introduced a new class of objects that could be used to communicate to 3rd party APIs like Twitter, Facebook, or custom made to meet customer use cases. This was the API Reference that enabled a developer to start using this group of methods and types.
Subject Matter: .NET, C#, NinjaScript, WPF
Technology Used: Confluence, Help+Manual, JIRA
URL: https://ninjatrader.com/support/helpGuides/nt8/?share_service.htm

![Share%20Service%20NinjaTrader%208%20Help%20Guide/Untitled.png](Share%20Service%20NinjaTrader%208%20Help%20Guide/Untitled.png)

![Share%20Service%20NinjaTrader%208%20Help%20Guide/Untitled%201.png](Share%20Service%20NinjaTrader%208%20Help%20Guide/Untitled%201.png)